import { Component } from '@angular/core';

@Component({
  selector: 'app-checkbox-radio',
  templateUrl: './cr.component.html',
  styleUrls: ['./cr.component.css']
})
export class CheckradioComponent {}
