import { Component } from '@angular/core';

@Component({
  selector: 'app-form-horizontal',
  templateUrl: './horizontal.component.html',
  styleUrls: ['./horizontal.component.css']
})
export class FormhorizontalComponent {}
