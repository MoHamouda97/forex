import { Component } from '@angular/core';

@Component({
  selector: 'app-form-row-sep',
  templateUrl: './row-sep.component.html',
  styleUrls: ['./row-sep.component.css']
})
export class FormrowsepComponent {}
