import { Component } from '@angular/core';

@Component({
  templateUrl: 'basic.component.html'
})
export class BasicComponent {}
