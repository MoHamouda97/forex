import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GenericService } from 'src/services/generic/generic.service';
import { SliderService } from 'src/services/slider/slider.service';
import { TradesService } from 'src/services/trades/trades.service';
import * as lang from './../../../../settings/lang';

@Component({
  selector: 'app-add-trades',
  templateUrl: './add-trades.component.html',
  styleUrls: ['./add-trades.component.css']
})
export class AddTradesComponent implements OnInit {

  form: FormGroup;
  isAdd: boolean = false;
  imageName = 'اختر الصورة';
  image: any = '';
  data: any[] = [];

  constructor(public route: ActivatedRoute, private fb: FormBuilder, private service: TradesService, private generic: GenericService) { }

  ngOnInit() {
    this.service.getCurrencies().subscribe(
      res => {
        console.log( res.data);
        this.data = res.data;
      }
    )
    this.form = this.fb.group({
      CurrencyId: [''],
      enter: [''],
      exit: [''],
      notes: [''],
      vip: [''],

    });  

    
  }

  //#region Upload image
 

  //#endregion  01061310684

  async add() {
    this.isAdd = true;
    const data = await this.service.add(this.form.get('CurrencyId').value, this.form.get('enter').value,
     this.form.get('exit').value,
     this.form.get('notes').value,
      this.form.get('vip').value ? "1" : "0") ;
    this.isAdd = false;
    this.generic.showNotification('success', lang.ar.addNewTitle, lang.ar.addNewMsg)
    this.form.reset();
    this.imageName = 'اختر الصورة';
    this.image = '';
  }  

}
