import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/module/shared.module';
import { AddTradesComponent } from './add-trades/add-trades.component';
import { AllTradesComponent } from './all-trades/all-trades.component';


const routes: Routes = [{
  path: '',
  children: [
      {
          path: 'all',
          component: AllTradesComponent,
          data: {
              title: 'صفقات',
          }              
      },
      {
          path: 'add',
          component: AddTradesComponent,
          data: {
              title: 'اضافة صفقات',
          },                               
      },
  ]
}];

@NgModule({
  declarations: [
    AllTradesComponent,
    AddTradesComponent,

],

  imports: [RouterModule.forChild(routes)
    ,
   
        CommonModule,
        SharedModule,
  
  ],
  exports: [RouterModule]
})
export class TradesRoutingModule { }
